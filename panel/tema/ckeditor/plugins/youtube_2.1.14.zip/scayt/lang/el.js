﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'el', {
	btn_about: 'About SCAYT',
	btn_dictionaries: 'Λεξικά',
	btn_disable: 'Disable SCAYT',
	btn_enable: 'Enable SCAYT',
	btn_langs:'Γλώσσες',
	btn_options: 'Επιλογές',
	text_title: 'Spell Check As You Type'
});
