﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'es', {
	btn_about: 'Acerca de Corrector',
	btn_dictionaries: 'Diccionarios',
	btn_disable: 'Desactivar Corrector',
	btn_enable: 'Activar Corrector',
	btn_langs:'Idiomas',
	btn_options: 'Opciones',
	text_title: 'Comprobar Ortografía Mientras Escribe'
});
